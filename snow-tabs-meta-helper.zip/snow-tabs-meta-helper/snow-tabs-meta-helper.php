<?php
/**
 * Plugin Name: Snow Tabs Meta Helper (temporario)
 * Description: Libera o campo wb_custom_tabs dos produtos para escrita via REST. Remover apos o uso.
 * Version: 1.0
 */
add_action( 'init', function () {
	register_post_meta( 'product', 'wb_custom_tabs', array(
		'single'        => true,
		'type'          => 'array',
		'show_in_rest'  => array(
			'schema' => array(
				'type'  => 'array',
				'items' => array(
					'type'       => 'object',
					'properties' => array(
						'title'    => array( 'type' => 'string' ),
						'content'  => array( 'type' => 'string' ),
						'tab_type' => array( 'type' => 'string' ),
						'position' => array( 'type' => 'string' ),
						'nickname' => array( 'type' => 'string' ),
						'slug'     => array( 'type' => 'string' ),
					),
				),
			),
		),
		'auth_callback' => function () {
			return current_user_can( 'edit_products' );
		},
	) );
} );
