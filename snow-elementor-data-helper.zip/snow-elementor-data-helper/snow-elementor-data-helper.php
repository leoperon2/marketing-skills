<?php
/**
 * Plugin Name: Snow Elementor Data Helper (temporario)
 * Description: Libera o campo _elementor_data das paginas para escrita via REST, para quem pode editar a pagina. Remover apos o uso.
 * Version: 1.0
 */
add_action( 'init', function () {
	register_post_meta( 'page', '_elementor_data', array(
		'single'        => true,
		'type'          => 'string',
		'show_in_rest'  => true,
		'auth_callback' => function ( $allowed, $meta_key, $post_id ) {
			return current_user_can( 'edit_post', $post_id );
		},
	) );
} );
